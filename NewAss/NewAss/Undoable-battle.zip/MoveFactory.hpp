// This file contains a class that will create Battle Moves
#ifndef BATTLE_MOVE_FACTORY_H
#define BATTLE_MOVE_FACTORY_H

class MoveFactory
{
    public:
        static BattleMove* BuildMove(MoveType type, Actor* self, Actor* other)
		{
            BattleMove* move; 
            switch(type){
                case MoveType::AttackOne:
                    move =  new AttackOne(self, other);
                    break;
                case MoveType::AttackTwo:
                    move = new AttackTwo(self, other);
                    break; 
                case MoveType::Heal:
                    move =  new Heal(self, other);
                    break;
                default: 
                    throw "unknown move";
            }
            return move; 
        }
};

#endif