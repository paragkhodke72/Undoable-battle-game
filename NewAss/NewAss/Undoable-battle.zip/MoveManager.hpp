// This file contains a class that Will handle a stack of moves
#ifndef MOVE_MANAGER
#define MOVE_MANAGER

// comment/uncoment below to change stack 

// #include "Stack.hpp"
#include <LStack.hpp>

class MoveManager : public LStack<IMove*>   // change to Stack<IMove*>
{
    public:
        // takes a move as argument and push into the stack
        void ExecuteMove(IMove* move)
        {
            move->execute();
            this->push(move);
        }

        // undo the last move in the stack
        void UndoLastMove()
        {
            this->top()->undo();
            this->pop();
        }
};

#endif