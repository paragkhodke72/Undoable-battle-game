// This file contains character classes definition

#ifndef Actor_H
#define Actor_H

#include <vector>

// General game character
class Actor
{
	public:
		Actor(int h, std::string s);
		Actor(const Actor & act);
		Actor & operator= (const Actor & act);
		
		// performs actor's move, it will go through the MoveManager's method so that history is recorded on the stack
		void doMove(MoveManager & mgr, const MoveType & moveType, Actor * other );
		
		// actor is damaged by certain amount
		void hit(int damage);

		// actor is healed by certain amount
		void heal(int amount);

		// list of battle moves
		const std::vector<MoveType> & getMoves() const;
		
		// checks if the actor is dead
		bool isDead() const;

	protected:
		int health;
		std::string type;
		std::vector<MoveType> moves;


		friend std::ostream & operator<< (std::ostream & out, const Actor & act);
};

// Game character with 100hp and AttackOne, Heal battle moves
class Ghost : public Actor
{
	public:
		Ghost(int h = 100, std::string t = "Ghost") : Actor(h, t)
		{
			moves.push_back(MoveType::AttackOne);
			moves.push_back(MoveType::Heal);
		}
		
};

// Game character with 100hp and AttackTwo, Heal battle moves
class Knight : public Actor
{
	public:
		Knight(int h = 100, std::string t = "Knight") : Actor(h, t)
		{
			moves.push_back(MoveType::AttackOne);
			moves.push_back(MoveType::Heal);
		}
		
};

// Game character with 100hp and AttackOne, AttackTwo battle moves
class Warrior : public Actor
{
	public:
		Warrior(int h = 100, std::string t = "Warrior") : Actor(h, t)
		{
			moves.push_back(MoveType::AttackOne);
			moves.push_back(MoveType::AttackTwo);
		}
		
};

#endif