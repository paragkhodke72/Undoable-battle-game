void Runner::run()
{
    std::cout << "\nSelect a player:" << '\n';
    std::cout << "\n1) Ghost" << '\n';
    std::cout << "\n2) Knight" << '\n';
    std::cout << "\n3) Warrior" << '\n';

    char in;
    std::cin >> in;

    while(not isdigit(in)) {
        if ('1' <= in and in <= '3')
            break;
        
        std::cout << "unknown character, please enter again: ";
        std::cin >> in;
    }

    std::cout << "You selected: " << ActorTypeStrings[in-'0'-1] << '\n';

    Actor* player = ActorFactory::CreateActor(ActorType(in-'0'-1));

    std::cout << "Select a Opponent:" << '\n';
    std::cout << "1) Ghost" << '\n';
    std::cout << "2) Knight" << '\n';
    std::cout << "3) Warrior" << '\n';

    std::cin >> in;

    while(not isdigit(in)) {
        if ('1' <= in and in <= '3')
            break;
        
        std::cout << "unknown character, please enter again: ";
        std::cin >> in;
    }

    std::cout << "You selected: " << ActorTypeStrings[in-'0'-1] << '\n';
    
    Actor* opponent = ActorFactory::CreateActor(ActorType(in-'0'-1));

    std::cout << "Beginning match!" << '\n';
    std::cout << "[" << (*player) << "],[" << (*opponent) << "]\n";
    std::cout << "-----------------------------------" << '\n';
   
    MoveManager mngr;

    while (not (*player).isDead() and not (*opponent).isDead()) {
        std::cout << "Choose a move:" << '\n';
        std::cout << "1) P1 -> P2" << '\n';
        std::cout << "2) P2 -> P1" << '\n';
        std::cout << "3) Undo" << '\n';

        std::cin >> in;

        while(not isdigit(in)) {
            if ('1' <= in and in <= '3')
                break;
            
            std::cout << "unknown move, please enter again: ";
            std::cin >> in;
        }

        int r = rand()%(3);

        if (in == '1') 
            (*player).doMove(mngr, MoveType(r), opponent);
        else if (in == '2')
            (*opponent).doMove(mngr, MoveType(r), player);
        else 
        {
            try
            {
                mngr.UndoLastMove();
            }
            catch(const char* & exec)
            {
                std::cout << exec << '\n';
            }
        }
        std::cout << "[" << (*player) << "],[" << (*opponent) << "]\n";
    }


}
/*1
You selected: 1
Select an opponent:
1) Ghost
2) Knight
3) Warrior
3
You selected: 3
Beginning match!
Ghost, (100)
Warrior, (100)
Ghost, (100)
Warrior, (100)
-----------------------------------
Choose move:
1) P1 -> P2
2) P2 -> P1
3) Undo
1
Ghost, (100) used: Heal
Ghost, (100) is healed by 13 hp.
[Player: Ghost, (113)][Opponent: Warrior, (100)]
Choose move:
1) P1 -> P2
2) P2 -> P1
3) Undo
2
Warrior, (100) used: AttackOne
Ghost, (113) is hit with 12 damage.
[Player: Ghost, (101)][Opponent: Warrior, (100)]
Choose move:
1) P1 -> P2
2) P2 -> P1
3) Undo
1
Ghost, (101) used: Heal
Ghost, (101) is healed by 12 hp.
[Player: Ghost, (113)][Opponent: Warrior, (100)]
Choose move:
1) P1 -> P2
2) P2 -> P1
3) Undo
2
Warrior, (100) used: AttackOne
Ghost, (113) is hit with 12 damage.
[Player: Ghost, (101)][Opponent: Warrior, (100)]
Choose move:
1) P1 -> P2
2) P2 -> P1
3) Undo
3
Ghost, (101) is healed by 12 hp.
[Player: Ghost, (113)][Opponent: Warrior, (100)]

}*/