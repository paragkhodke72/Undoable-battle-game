#ifndef ENUMS_H
#define ENUMS_H

// These will make it easy to set up a switch/case statement to instantiate the correct moves and actors based on user input

enum class MoveType { AttackOne, AttackTwo, Heal };
std::string MoveTypeStrings[] = { "AttackOne", "AttackTwo", "Heal" };

enum class ActorType { Ghost, Knight, Warrior };
std::string ActorTypeStrings[] = { "Ghost", "Knight", "Warrior" };

#endif
