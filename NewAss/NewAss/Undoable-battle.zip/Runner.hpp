#ifndef RUNNER_H
#define RUNNER_H

// This file contains the definition of a class to run the battle

class Actor;

#include <enums.hpp>
#include <BattleMove.hpp>
#include <MoveManager.hpp>
#include <MoveFactory.hpp>
#include <Actor.hpp>
#include <ActorFactory.hpp>

#include <Actor.cpp>
#include <BattleMove.cpp>

class Runner
{
    public:
        void run();
};

#include <Runner.cpp>

#endif