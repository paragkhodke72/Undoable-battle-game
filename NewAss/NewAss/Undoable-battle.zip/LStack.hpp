// This file contains the definition of a Stack ADT implemented as a Single Linked List
#ifndef LSTACK_H
#define LSTACK_H

template <typename Object>
class LStack 
{
    private:
        // Node struct which represents each element in the list.
		struct Node
		{
			Object data;
			Node *next;
			
			Node(const Object & d = Object(), Node *n = nullptr) : data(d), next(n)
			{
				// empty
			}
		};
    
    public:
        LStack();
        ~LStack();

        // insert an element at the top
        void push(const Object & v);

        // erase the element at the top 
        void pop();

        // returns the element at the top
        const Object & top() const;
        Object & top();

        // check if the stack is empty
        bool empty();

        // returns the number of elements
        int size() const;

    private:
        int theSize;
        Node* head;
        
        // returns the element i positions after head node
        Node* get(int i);
};

#include <LStack.cpp>

#endif