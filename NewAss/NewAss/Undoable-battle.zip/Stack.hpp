// This file contains the definition of a Stack ADT implemented as a dynamic array

#ifndef STACK_H
#define STACK_H

template <typename Object>
class Stack
{
    public:
        Stack();
        ~Stack();

        // insert an element at the top
        void push(const Object & x);
        
        // erase the element at the top 
        void pop( );
        
        // returns the element at the top
        const Object & top() const;
        Object & top();

        // check if the stack is empty
        bool empty( ) const;

        // returns the number of elements
        int size( ) const;

        // returns the maximum current capacity
        int capacity( ) const;

    private:
        int theSize, theCapacity;
        Object * objects;


        void resize(int newSize);
        void reserve(int newCapacity);
};

#include "../src/Stack.cpp"

#endif