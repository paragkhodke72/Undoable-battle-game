template <typename Object>
Stack<Object>::Stack() : theSize(0), theCapacity(16)
{
    objects = new Object[ theCapacity ];
}

template <typename Object>
Stack<Object>::~Stack()
{
    delete[] objects;
}

template <typename Object>
bool Stack<Object>::empty( ) const
{ 
    return size( ) == 0; 
}

template <typename Object>
int Stack<Object>::size( ) const
{ 
    return theSize; 
}

template <typename Object>
int Stack<Object>::capacity( ) const
{ 
    return theCapacity; 
}    

template <typename Object>
void Stack<Object>::push( const Object & x )
{
    if( theSize == theCapacity )
        reserve( 2 * theCapacity + 1 );
    objects[ theSize++ ] = x;
}

template <typename Object>
void Stack<Object>::pop()
{
    if(empty())
        throw "stack is empty";
    theSize--;
}

template <typename Object>
Object & Stack<Object>::top() 
{
    if (empty())
        throw "stack is empty";
    
    return objects[theSize - 1];
}

template <typename Object>
void Stack<Object>::resize(int newSize)
{
    if( newSize > theCapacity )
        reserve( newSize * 2 );
    theSize = newSize;
}


template <typename Object>
void Stack<Object>::reserve(int newCapacity)
{
    Object *oldArray = objects;

    int numToCopy = newCapacity < theSize ? newCapacity : theSize;
    newCapacity += 16;
    objects = new Object[ newCapacity ];
    
    for( int k = 0; k < numToCopy; k++ )
        objects[ k ] = oldArray[ k ];

    theSize = numToCopy;
    theCapacity = newCapacity;

    delete[] oldArray;
}
