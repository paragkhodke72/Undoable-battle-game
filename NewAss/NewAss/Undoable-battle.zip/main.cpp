#include <iostream>

#include <Runner.hpp>

using namespace std;

int main() {
  Runner().run();
  return 0;
}