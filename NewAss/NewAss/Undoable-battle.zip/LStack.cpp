template <typename Object>
LStack<Object>::LStack() : theSize(0), head(nullptr)
{
    // empty
}
template <typename Object>
LStack<Object>::~LStack()
{
    while(not this->empty())
        this->pop();
}

template <typename Object>
void LStack<Object>::push(const Object & v) 
{
    Node* vtx = new Node(); // create new vertex vtx from item v
    vtx->data = v;
    vtx->next = head; // link this new vertex to the (old) head vertex
    head = vtx; // the new vertex becomes the new head
    theSize++;
}

template <typename Object>
const Object & LStack<Object>::top() const
{
    if (this->empty())
        throw "stack is empty";

    return get(0)->data;
}
template <typename Object>
Object & LStack<Object>::top() 
{
    if (this->empty())
        throw "stack is empty";

    return get(0)->data;
}

template <typename Object>
void LStack<Object>::pop() 
{   
    if (this->empty()) // avoid crashing when SLL is empty
        throw "stack is empty";

    Node* temp = head; // so we can delete it later
    head = head->next; // book keeping, update the head 
    theSize--;
    delete temp; // which is the old head
}

template <typename Object>
bool LStack<Object>::empty()
{
    return theSize == 0;
}

template <typename Object>
typename LStack<Object>::Node* LStack<Object>::get(int i) { // returns the vertex
    Node* ptr = head; // we have to start from head
    for (int k = 0; k < i; k++) // advance forward i time(s)
        ptr = ptr->next; // the pointers are pointing to the higher index
    return ptr;
}

template <typename Object>
int LStack<Object>::size() const 
{
    return theSize;
}