Actor::Actor(int h, std::string t) : health(h), type(t) 
{
	// empty
}

Actor::Actor(const Actor & act) : health(act.health), type(act.type), moves(act.moves)
{
	// empty
}

Actor & Actor::operator= (const Actor & act)
{
    health = act.health;
    type = act.type;
    moves = act.moves;

    return *this;
}

void Actor::hit(int damage)
{
    std::cout << (*this) << " is hit with " << damage << " damage.\n";
    health -= damage;
}

void Actor::heal(int amount)
{
    std::cout << (*this) << " is healed by " << amount << "hp.\n";
    health += amount;
}

const std::vector<MoveType> & Actor::getMoves() const
{
    return moves;
}

bool Actor::isDead() const
{
    return health <= 0;
}

void Actor::doMove(MoveManager & mgr, const MoveType & moveType, Actor * other ) 
{
    std::cout << type << " ,(" << health << ") used " << MoveTypeStrings[(int)moveType] << '\n'; 
    mgr.ExecuteMove(MoveFactory::BuildMove(moveType, this, other));
}

std::ostream & operator<< (std::ostream & out, const Actor & act)
{
    out << act.type << ", (" << std::to_string(act.health) << ")";
    return out;
}